package com.example.lobstersale.models

class Lobster(name: String, price: Double) : Product(name, price) {
    override fun getProductType(): String {
        return "Lobster"
    }
}
