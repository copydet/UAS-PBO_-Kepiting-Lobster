package com.example.lobstersale.models

abstract class Product(val name: String, val price: Double) {
    abstract fun getProductType(): String
}
